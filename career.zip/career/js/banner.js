let slideIndex = 0;
showSlides();

// Show next/previous slides
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Show specific slide based on dot navigation
function currentSlide(n) {
    showSlides(slideIndex = n - 1);
}

// Function to show slides
function showSlides(n) {
    const slides = document.querySelectorAll('.carousel-item');
    const dots = document.querySelectorAll('.dot');
    
    if (n >= slides.length) slideIndex = 0;
    if (n < 0) slideIndex = slides.length - 1;

    slides.forEach((slide, index) => {
        slide.style.display = 'none';
        dots[index].className = dots[index].className.replace(' active', '');
    });

    slides[slideIndex].style.display = 'block';
    dots[slideIndex].className += ' active';
}

// Automatic Slide Show
setInterval(() => {
    slideIndex++;
    showSlides(slideIndex);
}, 3000); // Change image every 5 seconds


// counter starts here
document.addEventListener("DOMContentLoaded", function () {
    const counters = document.querySelectorAll('.count');
    const speed = 200; // Adjust speed as necessary

    const countUp = (counter) => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText;
        
        const increment = target / speed;

        if (count < target) {
            counter.innerText = Math.ceil(count + increment);
            setTimeout(() => countUp(counter), 10);
        } else {
            counter.innerText = target;
        }
    };

    // Use IntersectionObserver to start counting when in view
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                countUp(entry.target);
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    counters.forEach(counter => observer.observe(counter));
});





















