// const slider = document.getElementById('imageSlider');
//   let currentIndex = 0;  // Track the current index
//   const totalImages = slider.children.length;
//   const visibleImages = 10;  // Number of visible images at a time
//   const imageWidth = 100 / visibleImages; // Each image occupies 10% of the width

//   // Function to move the slider
//   function moveSlider(direction) {
//     // Calculate new index
//     currentIndex += direction;
    
//     // Loop around the images
//     if (currentIndex < 0) {
//       currentIndex = totalImages - visibleImages;
//     } else if (currentIndex > totalImages - visibleImages) {
//       currentIndex = 0;
//     }

//     // Move the slider by updating the transform property
//     slider.style.transform = `translateX(-${currentIndex * imageWidth}%)`;
//   }

//   // Auto-slide functionality
//   function autoSlide() {
//     moveSlider(1);  // Move right by 1 set
//   }

//   // Start auto-sliding every 3 seconds
//   setInterval(autoSlide, 3000);





//   var totalGame = Math.floor(Math.random()*6) + 1;
// // console.log(totalGame);
// document.querySelector('.img1').src = 'image/dice' + totalGame + '.png';


// var everyGame = Math.floor(Math.random()*6) + 1;
// // console.log(everyGame);
// document.querySelector('.img2').src = 'image/dice' + everyGame + '.png'




// // document.querySelector('.ogerexxxz h4').innerHTML =''

// if(totalGame > everyGame){
//   document.querySelector('.ogerexxxz h4').innerHTML = 'PLAYER 1 WINS'
// }else if(everyGame > totalGame){
//   document.querySelector('.ogerexxxz h4').innerHTML = 'PLAYER 2 WINS'
// }else {
//   document.querySelector('.ogerexxxz h4').innerHTML = 'DRAW'

// }


// function ludo() {
//   var totalGame = Math.floor(Math.random()*6) + 1;
// // console.log(totalGame);
// document.querySelector('.img1').src = 'image/dice' + totalGame + '.png';


// var everyGame = Math.floor(Math.random()*6) + 1;
// // console.log(everyGame);
// document.querySelector('.img2').src = 'image/dice' + everyGame + '.png'




// // document.querySelector('.ogerexxxz h4').innerHTML =''

// if(totalGame > everyGame){
//   document.querySelector('.ogerexxxz h4').innerHTML = 'PLAYER 1 WINS'
// }else if(everyGame > totalGame){
//   document.querySelector('.ogerexxxz h4').innerHTML = 'PLAYER 2 WINS'
// }else {
//   document.querySelector('.ogerexxxz h4').innerHTML = 'DRAW'

// }
// }


// document.querySelector('.chinedu').addEventListener('click', ludo)



var careerGame = Math.floor(Math.random()*5) + 1;
// console.log(careerGame);
document.querySelector('.imgg').src = 'image/career' + careerGame + '.jpg'

var foodGame = Math.floor(Math.random()*5) + 1;
// console.log(foodGame)
document.querySelector('.imggs').src = 'image/food' + foodGame + '.jpg'

var kingGame = Math.floor(Math.random()*5) + 1;
// console.log(kingGame);
document.querySelector('.imggsss').src = 'image/king' + kingGame + '.jpg'

var politicGame = Math.floor(Math.random()*5) + 1;
// console.log(politicGame);
document.querySelector('.imaggss').src = 'image/politician' + politicGame + '.jpg'

if(careerGame === 'career'){
    document.querySelector('.carz h4').innerHTML = 'A pilot'
}else if(foodGame === foodGame){
    document.querySelector('.foodss h4').innerHTML = 'egusi soup'
}else if(politicGame === politicGame){
    document.querySelector('.politic h4').innerHTML = 'Tinubu'
}else if(kingGame === kingGame){
    document.querySelector('.kings h4').innerHTML = 'OLU WARRI'
}else{
    alert('Not applicable')
}


// alert(' the first is the career ' + careerGame + ' the second is the food ' + foodGame + ' the third is the king' + ' ' + kingGame + ' ' + ' while the fourth is the politics' +' '+ politicGame)



// var pilot = 'An Architech'
// var engineer = 'An Engineer'
// var teacher = 'A Teacher'
// var pilot = 'A Pilot'
// var Doctor = 'A Doctor'
// var warri = 'Oluwarri of Warri'
// var ife = 'Oni of Ife'
// var benin = 'Oba of Benin'
// var onitsha = 'Obi of Onitsha'
// var Lagos = 'Oba of Lagos'
// var Egusi = 'Egusi Soup'
// var Beans = 'Plate of Beans'
// var Nsala = 'Nsala soup'
// var moimoi = 'Moi- Moi'
// var jollof = 'A Plate of Jollof rice'
// var tinubu = 'Tinubu'
// var atiku = 'Atiku'
// var babaginda = 'Ibrahim Babaginda'
// var shagari = 'Shagari'
// var muritala = 'Muritala Mohammed'


function applique() {
    var careerGame = Math.floor(Math.random()*5) + 1;
    // console.log(careerGame);
    document.querySelector('.imgg').src = 'image/career' + careerGame + '.jpg'
    
    var foodGame = Math.floor(Math.random()*5) + 1;
    // console.log(foodGame)
    document.querySelector('.imggs').src = 'image/food' + foodGame + '.jpg'
    
    var kingGame = Math.floor(Math.random()*5) + 1;
    // console.log(kingGame);
    document.querySelector('.imggsss').src = 'image/king' + kingGame + '.jpg'
    
    var politicGame = Math.floor(Math.random()*5) + 1;
    // console.log(politicGame);
    document.querySelector('.imaggss').src = 'image/politician' + politicGame + '.jpg'

    if (careerGame == 1) {
        document.querySelector('.artc').innerHTML = 'ARCHITECH'
    } else if (careerGame == 2) {
        document.querySelector('.artc').innerHTML = 'DOCTOR'
    }else if (careerGame === 3){
        document.querySelector('.artc').innerHTML = 'ENGINEER'
    }else if(careerGame ==4){
        document.querySelector('.artc').innerHTML = 'TEACHER'
    }else if(careerGame == 5){
        document.querySelector('.artc').innerHTML = 'PILOT'
    }else{
        alert('This is not applicable')
    }
    
    
    if(foodGame == 1){
        document.querySelector('.ounje').innerHTML = 'BEANS'
    }else if(foodGame == 2){
        document.querySelector('.ounje').innerHTML = 'EGUSI SOUP'
    }else if(foodGame == 3){
         document.querySelector('.ounje').innerHTML = 'NSALA'
    }else if(foodGame == 4){
         document.querySelector('.ounje').innerHTML = 'MOI-MOI'
    }else if(foodGame == 5){
         document.querySelector('.ounje').innerHTML = 'JOLLOF RICE'
    }else{
        alert('This is not applicable')
    }
    
    if(kingGame == 1){
        document.querySelector('.kkg').innerHTML = 'OBA OF BENIN'
    }else if(kingGame == 2){
        document.querySelector('.kkg').innerHTML = 'ONI OF IFE'
    }else if(kingGame == 3){
         document.querySelector('.kkg').innerHTML = 'OBI OF ONITSHA'
    }else if(kingGame == 4){
         document.querySelector('.kkg').innerHTML = 'OBA OF LAGOS'
    }else if(kingGame == 5){
         document.querySelector('.kkg').innerHTML = 'OLU WARRI OF WARRI'
    }else{
        alert('This is not applicable')
    }
    
    if(politicGame == 1){
        document.querySelector('.muri').innerHTML = 'ATIKU'
    }else if(politicGame == 2){
        document.querySelector('.muri').innerHTML = 'SHAGARI'
    }else if(politicGame == 3){
         document.querySelector('.muri').innerHTML = 'TINUBU'
    }else if(politicGame == 4){
         document.querySelector('.muri').innerHTML = 'MURITALA MOHAMMED'
    }else if(politicGame == 5){
         document.querySelector('.muri').innerHTML = 'IBRAHIM BABAGINDA'
    }else{
        alert('This is not applicable')
    }

    
}





document.querySelector('.chan').addEventListener('click', applique)

  
  
